if [[ "$1" == "-h" || "1$" == "--help" ]]; then
   echo "Uso: $0 ORIGEN DESTINO"
   echo "Crea un backup .tar.gz del ORIGEN en DESTINO con fecha YYYYMMDD."
   exit 0
fi

if [ $# -ne 2 ]; then
   echo "Error: se requieren ORIGEN y DESTINO."
   exit 1
fi

ORIGEN="$1"
DESTINO="$2"

mountpoint -q "$ORIGEN" || { echo "Error: $ORIGEN no esta montado."; exit 2; }
mountpoint -q "$DESTINO" || { echo "Error: $DESTINO no esta montado."; exit 3; }

FECHA=$(date +%Y%m%d)
ARCHIVO="${DESTINO%/}/$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz"


tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"

echo "Backup creado en $ARCHIVO"
